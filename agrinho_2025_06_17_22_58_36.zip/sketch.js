// Projeto p5.js - Campo com Máquinas, Drones e Cidade ao Lado (Versão com Gráficos Mais Realistas)
let drones = [], clouds = [], machines = [];
let cityX = 50;

function setup() {
  createCanvas(800, 500);
  textFont('Arial');
  for (let i = 0; i < 3; i++) {
    drones.push({ x: 200 + i * 100, y: 100 + i * 20, dir: 1 });
  }
  for (let i = 0; i < 3; i++) {
    machines.push({ x: 250 + i * 100, y: 400, wheelAngle: 0 });
  }
  for (let i = 0; i < 2; i++) {
    clouds.push({ x: i * 200, y: 80 });
  }
}

function draw() {
  drawSky();
  drawSun();
  drawGround();
  drawField();
  drawCity();
  drawClouds();
  drawMachines();
  drawDrones();
  drawText();
}

function drawSky() {
  for (let y = 0; y < height; y++) {
    let c = lerpColor(color(100, 170, 255), color(220, 240, 255), y / height);
    stroke(c);
    line(0, y, width, y);
  }
  noStroke();
}

function drawSun() {
  noStroke();
  fill(255, 204, 0);
  ellipse(700, 80, 80, 80);
  fill(255, 204, 0, 80);
  ellipse(700, 80, 120, 120);
}

function drawGround() {
  noStroke();
  fill(85, 168, 89);
  rect(0, 400, width, 100);
  fill(75, 150, 75);
  rect(0, 430, width, 10);
}

function drawField() {
  fill(100, 140, 80);
  rect(200, 400, 600, 100);
  fill(255);
  textSize(14);
  text("🌾 Campo com tecnologia e produção", 500, 395);

  stroke(90, 110, 60);
  for (let i = 210; i < width; i += 20) {
    line(i, 400, i, height);
  }
  noStroke();
}

function drawCity() {
  fill(70);
  rect(cityX, 320, 60, 180, 6);
  rect(cityX + 70, 350, 50, 150, 6);
  fill(240);
  rect(cityX + 15, 340, 10, 10);
  rect(cityX + 85, 370, 10, 10);
  fill(255, 60, 60);
  ellipse(cityX + 30, 320, 8);
  fill(0);
  textSize(14);
  text("🏙️ Cidade", cityX + 50, 310);
}

function drawClouds() {
  fill(255, 255, 255, 230);
  for (let c of clouds) {
    c.x += 0.3;
    if (c.x > width + 100) c.x = -150;
    ellipse(c.x, c.y, 90, 50);
    ellipse(c.x + 30, c.y - 10, 70, 40);
    ellipse(c.x + 60, c.y, 90, 50);
  }
}

function drawMachines() {
  for (let m of machines) {
    m.wheelAngle += 0.1;
    m.x += 0.5;
    if (m.x > width + 60) m.x = 200;

    // corpo
    fill(255, 100, 50);
    rect(m.x, m.y - 30, 60, 30, 5);

    // cabine
    fill(255, 180, 100);
    rect(m.x + 15, m.y - 45, 30, 15, 3);

    // rodas com rotação
    fill(60);
    push();
    translate(m.x + 10, m.y);
    rotate(m.wheelAngle);
    ellipse(0, 0, 20);
    pop();

    push();
    translate(m.x + 50, m.y);
    rotate(m.wheelAngle);
    ellipse(0, 0, 20);
    pop();
  }
}

function drawDrones() {
  for (let d of drones) {
    d.x += d.dir * 1.5;
    if (d.x > width - 50 || d.x < 200) d.dir *= -1;

    fill(30);
    ellipse(d.x, d.y, 40, 15);
    stroke(0);
    line(d.x - 20, d.y, d.x + 20, d.y);
    noStroke();

    // hélices girando
    fill(100);
    ellipse(d.x - 20, d.y, 10, 10);
    ellipse(d.x + 20, d.y, 10, 10);

    fill(0, 255, 0, 120);
    ellipse(d.x, d.y + 25, 6 + sin(frameCount * 0.2) * 4);
  }
}

function drawText() {
  fill(0);
  textSize(16);
  textAlign(CENTER);
  text("🌐 A cidade envia tecnologia para o campo — juntos, produzem mais com inovação!", width / 2, 30);
}